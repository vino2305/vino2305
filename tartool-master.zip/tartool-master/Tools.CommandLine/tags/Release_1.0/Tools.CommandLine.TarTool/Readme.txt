﻿Extract TarTool.zip to a local folder.

Make sure TarTool.exe and ICSharpCode.SharpZipLib.dll are in the same directory.

Open a Command Prompt and run TarTool.exe to get the usage information

>TarTool.exe
Usage : 
>TarTool sourceFile destinationDirectory
>TarTool D:\sample.tar.gz ./
>TarTool sample.tgz temp
>TarTool -x sample.tar temp